package ko.or.bukedu.bakedo.dbhelper;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editTextDbName;
    Button selectBtn;
    TextView textViewLog;
    int DATABASE_VERSION = 1;//
    String TABLE_NAME = "employee";
    String DATABASE_NAME;
    MyDatabaseHelper helper;
    SQLiteDatabase db;
    String TAG = "MainActivity***";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        selectBtn = findViewById(R.id.button);
        editTextDbName = findViewById(R.id.editTextTextPersonName);
        textViewLog = findViewById(R.id.textView);
        selectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DATABASE_NAME = editTextDbName.getText().toString();
                helper = new MyDatabaseHelper(getApplicationContext()); //DATABASE_NAME DB를 create함.
                db = helper.getWritableDatabase();// 한 세트

                //insert하자
                if(insertItem(db)==false){
                    Toast.makeText(getApplicationContext(), "insert실패", Toast.LENGTH_LONG).show();

                }else{
                    Toast.makeText(getApplicationContext(), "insert 성공", Toast.LENGTH_LONG).show();
                }

                //조회하자
                selectItems(db);
                updateItem(db);
                selectItems(db);
                deleteItem(db);
                selectItems(db);
            }
        });
    }
    void deleteItem(SQLiteDatabase db){
        print("deleteItem()");
        String[] whereArgs = {"izzie"};
        int rowAffected = db.delete(TABLE_NAME, "name=?", whereArgs);
        print("deleteItem()");
    }

    void updateItem(SQLiteDatabase db){
        print("updateItem()");
        ContentValues values = new ContentValues();
        values.put("age", 90);
        String[] whereArgs = {"izzie", "20"};
        int rowAffected = db.update(TABLE_NAME, values, "name=? and age=?", whereArgs);
        print("업데이트된 레코드 수 "+rowAffected);
    }

    void selectItems(SQLiteDatabase db){
        String sql = "select * from "+TABLE_NAME+";";
        Cursor c = db.rawQuery(sql, null);
        if(c.getCount()<=0) {
            return;
        }
        while(c.moveToNext()){
            String name = c.getString(c.getColumnIndex("name"));
            int age = c.getInt(c.getColumnIndex("age"));
            String phone = c.getString(c.getColumnIndex("phone"));
            print(name +"/"+age+"/"+phone);
        }
    }

    boolean insertItem(SQLiteDatabase db) {
        ContentValues recordValues = new ContentValues();
        recordValues.put("name", "izzie");
        recordValues.put("age", 20);
        recordValues.put("phone", "114");
        long rowPosition = db.insert(TABLE_NAME, null, recordValues);
        if (rowPosition == -1) {
            print("insert 실패");
            return false;
        } else {
            print("insert 성공");
            return true;
        }
    }

    class MyDatabaseHelper extends SQLiteOpenHelper {

        public MyDatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        public MyDatabaseHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            //처음 데이터베이스가 만들어질때 호출됨.
            print("Helper onCreate()");
            String sql = "create table if not exists " + TABLE_NAME + "(id integer primary key autoincrement, name text, age integer, phone text);";
            print(sql);
            db.execSQL(sql);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
            //버전이 바뀌어 업그레이드될 때 호출됨.(ex. 테이블의 구조가 변경되어 버전이 3.0에서 4.0으로 변경된 경우)
            print("upgrade database from version " + oldV + " to" + newV);
            String sql = "drop table " + TABLE_NAME;
            db.execSQL(sql);
        }

        @Override
        public void onOpen(SQLiteDatabase db) {
            //DB가 오픈될 때 호출
            super.onOpen(db);
            print("onOpen()");
        }
    }

    void print(String str){
        Log.d(TAG, str);
        textViewLog.append("\n" + str);
    }
}