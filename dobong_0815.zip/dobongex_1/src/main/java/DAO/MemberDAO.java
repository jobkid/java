package DAO;
import java.sql.*;
import beans.Member;

public class MemberDAO {	

	private MemberDAO() {
	}//생성자 불가 아래의 인스턴스로만 사용하세요. 한개만 만들어야 하니까
	
	//서블릿이 일하기 위한 메서드(동작)
	private static MemberDAO instance=new MemberDAO();//변수명 맞네 이렇게 생성자 1번만 생성 private이니까
	
	public static MemberDAO getInstance() {
		return instance;//위의 만든 객체를 꺼낼수 있도록 변수명 리턴
	}
	//우와~~ 이해안간다 
	//사용자 인증처리(로그인)리턴값에 따라서 반환값을 받음
	
	//커넥션 연결을 위한 메서드
	public Connection getConnection() throws Exception{
		Connection conn =null;
		String url="jdbc:mysql://127.0.0.1:3306/study";
		String db_id="root";
		String db_pw="iotiot";
		Class.forName("com.mysql.cj.jdbc.Driver");
		conn=DriverManager.getConnection(url,db_id,db_pw);
		return conn;
	}
	
	
	public int userCheck(String userid, String pwd) {
			int result=-1;//이쪽에서 변동을 주게됨 
			
			String sql="select pwd from member where userid=?";
			Connection conn=null;
			PreparedStatement pstmt=null;
			ResultSet rs=null;
			//메서드화
			
			try {
				conn=getConnection();
				//아~ conn에 위에 만들 메서드의 리턴값을 넣어주었음 그래서 써준것! 
				pstmt=conn.prepareStatement(sql);
				pstmt.setString(1,userid);
				rs=pstmt.executeQuery();
				if(rs.next()) {//해당 아이디가 존재하는 경우(2)
					if(rs.getString("pwd").equals(pwd) && rs.getString("pwd")!=null) {
						//아이디가 존재 패스워드가 같은가→ 또는 패스워드가 null이라면
						//인증
						result=1;
						//1이면 모든게 일치
					}else {
						//비밀번호가 없거나 일치하지 않는경우→ 사용자에게 친절하게 알려주기 위해 세분화한 작업
						//비번찾기
						result=0;
						
					}
				}else {//해당 아이다가 존재하지 않는 경우
					//회원가입유도
					result=-1;
				}
				
			}catch(Exception e) {	
				System.out.println("로그인중 오류 발생"+e);
			}finally {
				try {
					if(rs!=null) rs.close();
					if(pstmt!=null) pstmt.close();
					if(conn!=null) conn.close();
				}catch(Exception e) {
					System.out.println("로그인 회선 종료중 오류"+e);
				}
				
			}
		
			return result; //계산된 결과를 리턴함
	}
	
	//사용자 정보조회
	public Member getMember(String userid) {
		
		Member m=null;
		String sql="select *from member where userid=?";
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		try {
			conn=getConnection();//이걸로 대체
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			rs=pstmt.executeQuery();//rs에 익스큐트한 쿼리문을 담아줌
			
			if(rs.next()) {
				m=new Member();
				m.setNum(rs.getString("num"));
				m.setName(rs.getString("name"));
				m.setUserid(rs.getString("userid"));
				m.setPwd(rs.getString("pwd"));
				m.setEmail(rs.getString("email"));
				m.setEmail(rs.getString("phone"));
				m.setAdmin(rs.getString("admin"));
				//뒤쪽은 디비필드명 앞쪽은 빈즈의 메서드 이름!
				//여기가 헷갈리다고 하신건가봐
			}
		}catch(Exception e) {
			
			System.out.println("멤버 정보 조회 중 오류"+e);
			
		}finally {
			try {
				if(rs!=null)rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				System.out.println("멤버정보 조회중 종료 중 오류"+e);
			}
		}
		return m;
	}
	
//==========ID 중복체크 처리를 위한 메서드→ 퍼블릭으로 사용하지 않으면 다른곳에서 참조할 수 없음

	public int confirmID(String userid) {
		int result=-1;
		String sql="select userid from member where userid=?;";
		//바티스 다이나믹쿼리를 이용한데 한꺼번에 묶어서 사용한데 자동화의 세계는 끝이 없구만~~
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);//먼저 뭐리문을 넣고 시작
			pstmt.setString(1, userid);
			rs=pstmt.executeQuery();
			
			//rs가 있다? 아이디가 존재 가입불가!
			if(rs.next()) {
				result=1;//ID가 존재하는 경우
				System.out.println("1 id 존재");
			}else {
				
				result=-1;//ID 미존재
			}
		}catch(Exception e){
			System.out.println("MemberDao.confirmID() 접속중 오류 발생: "+e);
		}finally {
			try {
				if(rs!=null)rs.close();
				if(pstmt!=null)rs.close();
				if(conn!=null)conn.close();
				//모든 close는 역순으로 닫아주세요.
				
			}catch(Exception ex) {
				System.out.println("MemberDao.confirmID() 접속종료중 오류: "+ex);
			}
		}
		return result;
	} 
	
	//==========회원가입을 실행할 메서드
//	트랜잭션 처리
//	동시에 회원가입을 하면 X 데이터베이스 향상성 오류가 되지 않음
//	만약에 한꺼번에 넣는다면 다른사람들은 무조건 기다려야함 만약에 한번에 넣고싶다면
//	for을 통해 넣는걸을 추천 그리고 insert는 1번에 1줄이라고 기억하는게 좋음!
//	개념이 충통될수 있데
	public int insertMember(Member m) {
		int result=-1;
		
		String sql="insert into member(name, userid, pwd, email, phone, admin) values(?,?,?,?,?,?)";
		Connection conn=null;
		PreparedStatement pstmt=null;

		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, m.getName());
			pstmt.setString(2, m.getUserid());
			pstmt.setString(3, m.getPwd());
			pstmt.setString(4, m.getEmail());
			pstmt.setString(5, m.getPhone());
			pstmt.setString(6, m.getAdmin());
			result=pstmt.executeUpdate();
			//변경된 row수가 return값이므로 insert문을 항상 1을 반환함 
			//왜? 업데이트를 사용했나? 리턴타입이 int라서 executeUpdate 써줌 꼭 그걸 따르지 않아도 되면 select는 꼭 executeQuery 써야함 
		}catch(Exception e) {
			System.out.println("memberDAO. insertMember()실행중 오류: "+e);
			
		}finally{
			try {
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
				
			}catch(Exception e) {
				System.out.println("memberDAO.insertMember()종료중 오류발생 "+e);
				
			}
		}
			
		return result;
		
		
	}
	
}//c
