package controler;

import java.io.IOException;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import DAO.MemberDAO;
import beans.Member;



@WebServlet("/login.do")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public LoginServlet() {
       
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dis=request.getRequestDispatcher("login.jsp");
		//login.jsp을 읽고 써블릿이 값들을 읽고 있음 페이지를 읽고 있는게 아니고 
		dis.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url="login.jsp";//변하는 값이 필요해서 변수에 넣음
		request.setCharacterEncoding("utf-8");
		String userid=request.getParameter("userid");
		String pwd=request.getParameter("pwd");//-로그인 확인 콘솔창 System.out.println(userid+", "+pwd);
		
		//써블릿마다 객체를 만들면 안되니까 싱글톤 패턴으로 만들어서 객체생성 불가!
		//멤버다오에있는 만들어진 instance를 가지고 오자
		MemberDAO mDAO=MemberDAO.getInstance();
		int result=mDAO.userCheck(userid, pwd);
		System.out.println("로그인 결과"+result);
		//1로그인 성공 / 0비번틀림 / -1아이디 없음
		
		if(result==1) {
			//해당멤버의 정보를 가져와서 세션에 저장
			//데이터을 가져와서 보여주는것! 객체를 세션에 넣음! 로그인 하면? 세션 1:1이 가능하니까
			//url값 보정, 로그인 성공시 메인페이지로 이동
			
			//리퀘스트 셋해준 값들은 모두 로그인 jsp페이지로 이동 
				//성공, 비번, 미존재 모두 다 리퀘스트로 메세지:0000을 이렇게 넣어준 상태
			Member m=mDAO.getMember(userid);
			//mDAO을 만들어서 .getMember메서드 사용(userid을 받아서)
			HttpSession session=request.getSession();
			//세션을 이용하는데 새로만드는것이(new을 하게되면 계속 세션이 생성되니까) 아니라 리퀘스트받은 세션을 사용함
			session.setAttribute("loginUser", m);
			//멤버 m객체(모든데이터가 있는)을 세션에 넣어줌 여기서 로그인user가 뭐지? 
			//세션은 오브젝트 타입→ 캐스팅 필요
			request.setAttribute("message", "로그인 성공");
			url="main.jsp";			
			
		}else if(result==0) {
			//비번 오류 안내메시지 전달
			request.setAttribute("message", "비번 불일치");
		}else if(result==-1) {
			//아이디가 존재하지 않는다는 안내메시지 전달
			request.setAttribute("message", "미존재 회원");
		}
		RequestDispatcher dis=request.getRequestDispatcher(url);
		dis.forward(request, response);
	}

}
