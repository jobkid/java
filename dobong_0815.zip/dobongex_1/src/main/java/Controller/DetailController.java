package Controller;

import java.io.IOException;
import java.net.http.HttpClient;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.io.IOException;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.Notice;



@WebServlet("detail.jsp")
public class DetailController extends HttpClient {
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int id = Integer.parseInt(request.getParameter("id")); 		
		String url= "jdbc:mysql://localhost:3306/dobong1";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection(url, "root", "iotiot");
			
			String sql = "SELECT * FROM NOTICE WHERE ID = ?";
			PreparedStatement pstmt= conn.prepareStatement(sql);	
			pstmt.setInt(1, id);
			
			ResultSet rs= pstmt.executeQuery();
			rs.next();
			
			String title = rs.getString("TITLE") ;
			String writerId = rs.getString("WRITER_ID");
			Date regdate = rs.getDate("REGDATE");
			String hit = rs.getString("HIT");
			String files =rs.getString("FILES");
			String content = rs.getString("CONTENT");
			
			/*
			request.setAttribute("title", title);
			request.setAttribute("writerId", writerId);
			request.setAttribute("regdate", regdate);
			request.setAttribute("hit", hit);
			request.setAttribute("files", files);
			request.setAttribute("content", content);
			 */
			
			Notice notice = new Notice(id, title, writerId, regdate, hit, files, content);
			request.setAttribute("n", notice);
			
			rs.close();
			pstmt.close();
			conn.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		request.getRequestDispatcher("detail.jsp").forward(request, response);
	
	}	
}