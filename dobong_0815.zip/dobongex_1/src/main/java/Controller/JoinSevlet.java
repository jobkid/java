package Controller;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import beans.Member;
import DAO.MemberDAO;



@WebServlet("/join.do")
public class JoinSevlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    //같은 주소로 form method="get"으로 실행시 실행
	//127.0.0.1:8080/Board01/join.do a태그 또는 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dis=request.getRequestDispatcher("/register.jsp");
		//디스패처 실행이 되면서 웹앱에 있는 레지스터.jsp읽어줌
		dis.forward(request, response);
		//포워드로 리퀘스트를 그대로 유지함 
	}

	//같은 주소로 form method="post"으로 실행시 실행
	//127.0.0.1:8080/Board01/join.do ★a태그★ 또는 ★form★ method="post"으로 실행시 실행
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//register.jsp에서 데이터값 확인
		request.setCharacterEncoding("utf-8");
		String name=request.getParameter("name");
		String userid=request.getParameter("userid");
		String pwd=request.getParameter("pwd");
		String email=request.getParameter("email");
		String phone=request.getParameter("phone");
		String admin=request.getParameter("admin");
		System.out.println(name+","+userid+","+pwd+","+email+","+phone+","+admin);
		
		Member m=new Member();
		m.setName(name);
		m.setUserid(userid);
		m.setPwd(pwd);
		m.setEmail(email);
		m.setPhone(phone);
		m.setAdmin(admin);
		//멤버타입을 받는 메서드를 만들면 것만 넣어주면 가능하데
		
		MemberDAO mDAO=MemberDAO.getInstance();
		//생성자 못써서 객체를 가지고 옴
		int result=mDAO.insertMember(m);
		//결과값을 보기위해 인트타입변수로 받아줌
		
		HttpSession session=request.getSession();
//		└ 세션을 새로 만들지 않고 리퀘스트를 받은쪽의 세션을 가지고 온다
//		세션 리퀘스트가 있어야 생성이 된다
		 if(result==1) {
			 session.setAttribute("userid", m.getUserid());
			 request.setAttribute("message","회원가입에 성공");
		 }else {
			 request.setAttribute("mesaage","회원가입 실패");
			 //안내문적을때는 사용자가 다음단계를 준비할 수 있도록 안내문을 적어주자
		 }
		RequestDispatcher dis=request.getRequestDispatcher("login.do");
		dis.forward(request, response);
		
	}

}
