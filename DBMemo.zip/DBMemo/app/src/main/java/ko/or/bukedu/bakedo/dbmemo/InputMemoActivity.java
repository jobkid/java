package ko.or.bukedu.bakedo.dbmemo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class InputMemoActivity extends AppCompatActivity {

    Button saveButton, cancelButton;
    EditText inputMemo;
    String DATABASE_NAME = "MemoNote";
    int DATABASE_VERSION;
    String TABLE_NAME = "Memo";
    MyDatavaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_memo);

        saveButton = findViewById(R.id.button);
        cancelButton = findViewById(R.id.button2);
        inputMemo = findViewById(R.id.editTextTextPersonName);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveButton.
            }
        });
    }

    class MyDatavaseHelper extends SQLiteOpenHelper{
        public MyDatavaseHelper(Context context){
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        public MyDatavaseHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }

        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {
            String sql = "create table if not exists "+TABLE_NAME+" (_id integer primay key autoincrement, memo text);";
            db.execSQL(sql);
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        }
    }
}