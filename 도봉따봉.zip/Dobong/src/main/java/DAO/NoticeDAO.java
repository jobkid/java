package DAO;
import Beans.NoticeBean;
import java.sql.*;
import java.util.ArrayList;

public class NoticeDAO {
	
	String url = "jdbc:mysql://127.0.0.1:3306/dobong1";
	private final String URL = "jdbc:mysql://127.0.0.1:3306/dobong1";
	private final String ID = "root";
	private final String PASS = "iotiot";
	private final String DRIVER="com.mysql.cj.jdbc.Driver";
	private static NoticeDAO instance = new NoticeDAO();
	
	
	
	public Connection getConnection() throws Exception {
		Class.forName(DRIVER);
		Connection conn = null;
		conn = DriverManager.getConnection(URL, ID, PASS);
		return conn;
	}
	
	public ArrayList <NoticeBean> getNotice() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<NoticeBean> noticeList = new ArrayList<NoticeBean>();
		String Query = "select *from notice";
		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(Query);
			while(rs.next()) {
				NoticeBean notice = new NoticeBean();
				notice.setNumber(rs.getString("number"));
				notice.setNickname(rs.getString("nickname"));
				notice.setTitle(rs.getString("title"));
				notice.setContent(rs.getString("content"));
				notice.setFile(rs.getString("file"));
				notice.setWritingtime(rs.getString("writingtime"));
				notice.setChangetime(rs.getString("changetime"));
				noticeList.add(notice);
			}
		}catch(Exception e) {
			System.out.println("�Խ��� ���� ��ȸ �� ���� �߻�"+e);
		}finally{
			try {
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
				if(conn!=null)conn.close();
			}catch(Exception ex) {
				System.out.println("�Խ��� ���� ��ȸ ���� �� ���� �߻�"+ex);
			}
				
		}
		return noticeList;
	}
	/*
	public NoticeBean getNotice(NoticeBean b) {
		NoticeBean notice;
		Connection conn = null;
		Statement
		return notice;
	}*/

}
