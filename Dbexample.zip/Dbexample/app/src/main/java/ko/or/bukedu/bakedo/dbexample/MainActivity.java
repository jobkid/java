package ko.or.bukedu.bakedo.dbexample;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText editTextDB, editTextTable, editTextName,editTextAge, editTextphone;
    Button buttonDB, buttonTable,buttonRecord,buttonSelect;
    TextView textView;

    SQLiteDatabase db;
    String TAG = "MainActivity***";
    Person person;
    ArrayList<Person> data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextDB = findViewById(R.id.editTextTextPersonName);
        editTextTable = findViewById(R.id.editTextTextPersonName2);
        editTextName = findViewById(R.id.editTextTextPersonName3);
        editTextAge = findViewById(R.id.editTextNumberDecimal);
        editTextphone = findViewById(R.id.editTextPhone);
        buttonDB = findViewById(R.id.button);
        buttonTable = findViewById(R.id.button2);
        buttonRecord = findViewById(R.id.button3);
        buttonSelect = findViewById(R.id.button4);;
        textView = findViewById(R.id.textView);;
        data = new ArrayList<>();

        buttonDB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String dbName = editTextDB.getText().toString();
                db = openOrCreateDatabase(dbName,
                        MODE_PRIVATE,
                        null
                );  //db 생성.
            }
        });

        //테이블 생성
        buttonTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String table = editTextTable.getText().toString();
                String sql = "create table if not exists "+table
                        +"(name text, age integer, phone text);";
                db.execSQL(sql);
            }
        });



        //String table = editTextTable.get
        //insert into table values (name, age, phone);
        //db.exeSQL(sql);

        //레코드 입력 동작 정의해주세요.
        buttonRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = editTextName.getText().toString();
                String age = editTextAge.getText().toString();
                String phone = editTextphone.getText().toString();
                String sql = "insert into "+editTextTable.getText().toString()
                        +" values ('"+name+"', "+Integer.parseInt(age)+", '"+phone+"');";
                print(sql);
                db.execSQL(sql);
                //db.execSQL(sql);
            }
        });

        buttonSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    String sql = "select * from " + editTextTable.getText().toString()+";";
                    print(sql);
                    Cursor c = db.rawQuery(sql, null);
                    if(c.getCount() <=0){//데이터가 없으면 return;
                        Toast.makeText(getApplicationContext(),
                                "데이터가 없음", Toast.LENGTH_LONG);
                        return;
                    }
                    print("===================");

                    while(c.moveToNext()){
                        String name = c.getString(c.getColumnIndex("name"));
                        int age = c.getInt(c.getColumnIndex("age"));
                        String phone = c.getString(c.getColumnIndex("phone"));
                        Person person = new Person(name, age, phone);
                        data.add(person);
                        print(person.toString());

                }
                print("===================");
            }
        });
    }
    void print(String str){
        Log.d(TAG, str);
        textView.append("\n"+str);
    }
}

class Person{
    String name;
    int age;
    String phone;

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", phone='" + phone + '\'' +
                '}';
    }

    public Person(String name, int age, String phone) {
        this.name = name;
        this.age = age;
        this.phone = phone;
    }
}